<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if($_SERVER["REQUEST_METHOD"] != "POST"){
    header("Location: index.php");
    exit();
}

$id = (int)$_POST["id"];
$nome = trim($_POST["nome"]);
$descricao = trim($_POST["descricao"]);
$ativo = (int)$_POST["ativo"];
$imagem = $_POST["imagem_antiga"];

/* Gerar novo slug */

$slug = strtolower($nome);
$slug = preg_replace('/[^a-z0-9]+/i', '-', $slug);
$slug = trim($slug, '-');

/* Verificar slug duplicado */

$sql = "SELECT id
        FROM categorias
        WHERE slug = ?
        AND id <> ?";

$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt,"si",$slug,$id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado) > 0){

    $_SESSION["erro_categoria"] = "Já existe outra categoria com este nome.";

    header("Location: editar.php?id=".$id);
    exit();
}

/* Upload da nova imagem */

if(isset($_FILES["imagem"]) && $_FILES["imagem"]["error"] == 0){

    $pasta = "../../uploads/categorias/";

    if(!is_dir($pasta)){
        mkdir($pasta,0777,true);
    }

    $ext = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));

    $novoNome = uniqid().".".$ext;

    $destino = $pasta.$novoNome;

    if(move_uploaded_file($_FILES["imagem"]["tmp_name"],$destino)){

        if(!empty($imagem) && file_exists("../../".$imagem)){
            unlink("../../".$imagem);
        }

        $imagem = "uploads/categorias/".$novoNome;
    }
}

/* Atualizar */

$sql = "UPDATE categorias
SET
nome = ?,
slug = ?,
imagem = ?,
descricao = ?,
ativo = ?
WHERE id = ?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(
$stmt,
"ssssii",
$nome,
$slug,
$imagem,
$descricao,
$ativo,
$id
);

if(mysqli_stmt_execute($stmt)){

    header("Location: index.php");
    exit();

}else{

    echo "Erro ao atualizar categoria.";

}
?>