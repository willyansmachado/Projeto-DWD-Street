<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if (!isset($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET["id"];

/* Verifica se existem produtos utilizando esta categoria */

$sql = "SELECT COUNT(*) AS total
        FROM produtos
        WHERE categoria_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);
$dados = mysqli_fetch_assoc($resultado);

if ($dados["total"] > 0) {

    $_SESSION["erro_categoria"] = "Não é possível excluir esta categoria, pois existem produtos vinculados a ela.";

    header("Location: index.php");
    exit();
}

/* Buscar imagem da categoria */

$sql = "SELECT imagem
        FROM categorias
        WHERE id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($resultado) == 0) {
    header("Location: index.php");
    exit();
}

$categoria = mysqli_fetch_assoc($resultado);

/* Excluir imagem */

if (!empty($categoria["imagem"])) {

    $arquivo = "../../" . $categoria["imagem"];

    if (file_exists($arquivo)) {
        unlink($arquivo);
    }

}

/* Excluir categoria */

$sql = "DELETE FROM categorias WHERE id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    $_SESSION["sucesso_categoria"] = "Categoria excluída com sucesso.";

} else {

    $_SESSION["erro_categoria"] = "Não foi possível excluir a categoria.";

}

header("Location: index.php");
exit();
?>