<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: index.php");
    exit();
}

$nome = trim($_POST["nome"]);
$descricao = trim($_POST["descricao"]);
$ativo = (int)$_POST["ativo"];

/* Gerar Slug */

$slug = strtolower($nome);
$slug = preg_replace('/[^a-z0-9]+/i', '-', $slug);
$slug = trim($slug, '-');

/* Verificar slug duplicado */

$sql = "SELECT id FROM categorias WHERE slug = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $slug);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado) > 0){

    $_SESSION["erro_categoria"] = "Já existe uma categoria com este nome.";

    header("Location: criar.php");
    exit();
}

/* Upload da imagem */

$imagem = "";

if(isset($_FILES["imagem"]) && $_FILES["imagem"]["error"] == 0){

    $pasta = "../../uploads/categorias/";

    if(!is_dir($pasta)){
        mkdir($pasta,0777,true);
    }

    $extensao = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));

    $nomeImagem = uniqid() . "." . $extensao;

    $destino = $pasta . $nomeImagem;

    if(move_uploaded_file($_FILES["imagem"]["tmp_name"],$destino)){

        $imagem = "uploads/categorias/" . $nomeImagem;

    }

}

/* Inserir */

$sql = "INSERT INTO categorias
(
nome,
slug,
imagem,
descricao,
ativo
)
VALUES
(
?,
?,
?,
?,
?
)";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(
$stmt,
"ssssi",
$nome,
$slug,
$imagem,
$descricao,
$ativo
);

if(mysqli_stmt_execute($stmt)){

    header("Location: index.php");
    exit();

}else{

    echo "Erro ao salvar categoria.";

}
?>