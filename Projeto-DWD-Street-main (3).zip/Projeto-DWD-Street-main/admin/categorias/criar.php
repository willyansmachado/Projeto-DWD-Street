<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");
?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Nova Categoria</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div style="display:flex;justify-content:space-between;align-items:center;width:100%;margin-bottom:30px;">

    <div>

        <h1 style="margin:0;">Nova Categoria</h1>

        <p style="color:#888;margin-top:6px;">
            Cadastre uma nova categoria.
        </p>

    </div>

    <a href="index.php" class="btn">

        <i class="fa-solid fa-arrow-left"></i>

        Voltar às Categorias

    </a>

</div>

<form
action="salvar.php"
method="POST"
enctype="multipart/form-data"
class="formulario">

<div class="grupo">

<label>Nome da Categoria</label>

<input
type="text"
name="nome"
placeholder="Ex.: Camisetas Oversized"
required>

</div>

<div class="grupo">

<label>Descrição</label>

<textarea
name="descricao"
rows="5"
placeholder="Digite uma breve descrição da categoria..."></textarea>

</div>

<div class="grupo">

<div class="preview">

</div>

<br>

<div class="grupo">

<label>Status</label>

<select name="ativo">

<option value="1">

Ativa

</option>

<option value="0">

Inativa

</option>

</select>

</div>

<br>

<div class="botoes">

<button
type="submit"
class="btn">

<i class="fa-solid fa-floppy-disk"></i>

Salvar Categoria

</button>

</div>

</form>

</div>

</div>

</div>

<script>

const imagem = document.getElementById("imagem");
const preview = document.getElementById("preview");

imagem.addEventListener("change",function(){

if(this.files.length){

const reader = new FileReader();

reader.onload = function(e){

preview.src = e.target.result;

}

reader.readAsDataURL(this.files[0]);

}

});

</script>

</body>

</html>