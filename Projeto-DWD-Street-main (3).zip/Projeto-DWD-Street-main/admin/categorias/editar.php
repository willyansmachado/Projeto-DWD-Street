<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if(!isset($_GET["id"])){
    header("Location: index.php");
    exit();
}

$id = (int)$_GET["id"];

$sql = "SELECT * FROM categorias WHERE id = ?";

$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado) == 0){
    header("Location: index.php");
    exit();
}

$categoria = mysqli_fetch_assoc($resultado);
?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Editar Categoria</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div style="display:flex;justify-content:space-between;align-items:center;width:100%;margin-bottom:30px;">

    <div>

        <h1 style="margin:0;">Editar Categoria</h1>

        <p style="color:#888;margin-top:6px;">
            Altere as informações da categoria.
        </p>

    </div>

    <a href="index.php" class="btn">

        <i class="fa-solid fa-arrow-left"></i>

        Voltar às Categorias

    </a>

</div>

<form
action="atualizar.php"
method="POST"
enctype="multipart/form-data"
class="formulario">

<input
type="hidden"
name="id"
value="<?= $categoria["id"] ?>">

<input
type="hidden"
name="imagem_antiga"
value="<?= $categoria["imagem"] ?>">

<div class="grupo">

<label>Nome da Categoria</label>

<input
type="text"
name="nome"
value="<?= htmlspecialchars($categoria["nome"]) ?>"
placeholder="Nome da categoria"
required>

</div>

<div class="grupo">

<label>Descrição</label>

<textarea
name="descricao"
rows="5"
placeholder="Descrição da categoria"><?= htmlspecialchars($categoria["descricao"]) ?></textarea>

</div>

<div class="grupo">

<label>Status</label>

<select name="ativo">

<option value="1" <?= $categoria["ativo"] ? "selected" : "" ?>>

Ativa

</option>

<option value="0" <?= !$categoria["ativo"] ? "selected" : "" ?>>

Inativa

</option>

</select>

</div>

<br>

<div class="botoes">

<button
type="submit"
class="btn">

<i class="fa-solid fa-floppy-disk"></i>

Salvar Alterações

</button>

</div>

</form>

</div>

</div>

</div>

<script>

const imagem = document.getElementById("imagem");
const preview = document.getElementById("preview");

imagem.addEventListener("change",function(){

    if(this.files.length){

        const reader = new FileReader();

        reader.onload = function(e){

            preview.src = e.target.result;

        }

        reader.readAsDataURL(this.files[0]);

    }

});

</script>

</body>

</html>