<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

$pesquisa = "";

$sql = "SELECT
            c.*,
            (
                SELECT COUNT(*)
                FROM produtos p
                WHERE p.categoria_id = c.id
            ) AS total_produtos
        FROM categorias c";

if(isset($_GET["pesquisa"]) && trim($_GET["pesquisa"]) != ""){

    $pesquisa = mysqli_real_escape_string($conn, trim($_GET["pesquisa"]));

    $sql .= " WHERE c.nome LIKE '%$pesquisa%'";
}

$sql .= " ORDER BY c.nome ASC";

$resultado = mysqli_query($conn,$sql);

$totalCategorias = mysqli_num_rows($resultado);
?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Categorias</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.topo{

display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
flex-wrap:wrap;
gap:20px;

}

.topo h1{

color:#fff;

}

.info{

color:#999;
margin-top:5px;

}

.form-pesquisa{
    display:flex;
    align-items:center;
    height:50px;
    padding:0;
    background:#181818;
    border:1px solid #2d2d2d;
    border-radius:12px;
    overflow:hidden;
}

.form-pesquisa input{
    width:250px;
    height:100%;
    padding:0 16px;
    border:none;
    outline:none;
    background:#181818;
    color:#fff;
    font-size:14px;
}

.form-pesquisa input::placeholder{
    color:#777;
}

.form-pesquisa button{
    width:50px;
    height:50px;
    border:none;
    background:#d90429;
    color:#fff;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}
.btn{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    height:48px;
    padding:0 22px;
    background:#d90429;
    color:#fff;
    text-decoration:none;
    border-radius:12px;
    font-weight:600;
    transition:.2s;
}

.btn:hover{
    background:#b80022;
    transform:translateY(-2px);
}
.tabela{

width:100%;
border-collapse:collapse;
background:#1b1b1b;
border-radius:10px;
overflow:hidden;

}

.tabela th{

background:#151515;
padding:16px;
color:#fff;

}

.tabela td{

padding:15px;
border-bottom:1px solid #2d2d2d;
color:#ddd;

}

.tabela tr:hover{

background:#242424;

}

.badge{

padding:6px 12px;
border-radius:20px;
font-size:13px;
font-weight:bold;

}

.verde{

background:#17863b;
color:#fff;

}

.vermelho{

background:#c1121f;
color:#fff;

}

.btnAcao{

padding:8px 12px;
border-radius:6px;
text-decoration:none;
color:#fff;
margin-right:5px;

}

.editar{

background:#0077ff;

}

.excluir{

background:#d90429;

}

</style>

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div class="topo">

<div>

<h1>Categorias</h1>

<p class="info">

<?= $totalCategorias ?> categoria(s)

</p>

</div>

<div style="display:flex;gap:10px;">

<form class="form-pesquisa">

<input
type="text"
name="pesquisa"
placeholder="Pesquisar categoria..."
value="<?= htmlspecialchars($pesquisa) ?>">

<button>

<i class="fa-solid fa-magnifying-glass"></i>

</button>

</form>

<a href="criar.php" class="btn">

<i class="fa-solid fa-plus"></i>

Nova Categoria

</a>

</div>

</div>

<table class="tabela">

<tr>

<th>Nome</th>

<th>Slug</th>

<th>Produtos</th>

<th>Status</th>

<th>Ações</th>

</tr>

<?php while($categoria=mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>

<strong>

<?= htmlspecialchars($categoria["nome"]) ?>

</strong>

</td>

<td>

<?= htmlspecialchars($categoria["slug"]) ?>

</td>

<td>

<?= $categoria["total_produtos"] ?>

</td>

<td>

<?php if($categoria["ativo"]){ ?>

<span class="badge verde">

Ativa

</span>

<?php }else{ ?>

<span class="badge vermelho">

Inativa

</span>

<?php } ?>

</td>

<td>

<a
href="editar.php?id=<?= $categoria["id"] ?>"
class="btnAcao editar">

<i class="fa-solid fa-pen"></i>

</a>

<a
href="excluir.php?id=<?= $categoria["id"] ?>"
class="btnAcao excluir"
onclick="return confirm('Deseja excluir esta categoria?')">

<i class="fa-solid fa-trash"></i>

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</div>

</body>

</html>