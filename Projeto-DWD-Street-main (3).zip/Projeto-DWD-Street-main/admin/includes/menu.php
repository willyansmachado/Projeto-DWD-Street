<div class="sidebar">

    <div class="logo">
        <h2>DWD <span>STREET</span></h2>
    </div>

    <ul>

        <li>
            <a href="/Projeto-DWD-Street-main/admin/dashboard.php">
                <i class="fa-solid fa-house"></i>
                Dashboard
            </a>
        </li>

        <li>
            <a href="/Projeto-DWD-Street-main/admin/produtos/index.php">
                <i class="fa-solid fa-box"></i>
                Produtos
            </a>
        </li>

        <li>
            <a href="/Projeto-DWD-Street-main/admin/categorias/index.php">
                <i class="fa-solid fa-layer-group"></i>
                Categorias
            </a>
        </li>

        <li>
            <a href="/Projeto-DWD-Street-main/admin/pedidos/index.php">
                <i class="fa-solid fa-cart-shopping"></i>
                Pedidos
            </a>
        </li>

        <li>
            <a href="/Projeto-DWD-Street-main/admin/clientes/index.php">
                <i class="fa-solid fa-users"></i>
                Clientes
            </a>
        </li>

    </ul>

</div>