<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if(!isset($_GET["id"])){
    header("Location: index.php");
    exit();
}

$id = (int)$_GET["id"];

$sql = "SELECT
p.*,
u.nome,
u.sobrenome,
u.email,
u.telefone
FROM pedidos p
INNER JOIN usuarios u
ON u.id = p.usuario_id
WHERE p.id = ?";

$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)==0){
    header("Location: index.php");
    exit();
}

$pedido = mysqli_fetch_assoc($resultado);

$itens = mysqli_query($conn,"
SELECT
i.*,
pr.nome
FROM itens_pedido i
INNER JOIN produtos pr
ON pr.id=i.produto_id
WHERE i.pedido_id=$id
");

switch($pedido["status"]){

    case "Aguardando Pagamento":
        $classe="status-pendente";
        $icone="fa-clock";
        break;

    case "Pagamento Aprovado":
        $classe="status-aprovado";
        $icone="fa-circle-check";
        break;

    case "Separando Pedido":
        $classe="status-separando";
        $icone="fa-box-open";
        break;

    case "Enviado":
        $classe="status-enviado";
        $icone="fa-truck";
        break;

    case "Saiu para Entrega":
        $classe="status-entrega";
        $icone="fa-truck-fast";
        break;

    case "Entregue":
        $classe="status-entregue";
        $icone="fa-circle-check";
        break;

    default:
        $classe="status-cancelado";
        $icone="fa-circle-xmark";

}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Pedido #<?= $pedido["codigo"] ?></title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.topo{

display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:30px;
flex-wrap:wrap;
gap:20px;

}

.topo h1{

font-size:30px;
color:#fff;

}

.data{

color:#888;
margin-top:6px;

}

.grid{

display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
margin-bottom:20px;

}

.card{

background:#1b1b1b;
border-radius:14px;
padding:25px;
border:1px solid #2b2b2b;

}

.card h2{

font-size:18px;
margin-bottom:18px;
color:#fff;
padding-bottom:12px;
border-bottom:1px solid #2d2d2d;

}

.card p{

margin-bottom:10px;
color:#ddd;
line-height:24px;

}

.badge{

    display:inline-flex;
    align-items:center;
    gap:8px;

    padding:8px 16px;

    border-radius:8px;

    font-size:13px;
    font-weight:600;

    border:1px solid transparent;

    box-shadow:none;

}

.badge i{

    font-size:12px;

}

.status-pendente{

    background:#3b2c06;
    color:#ffc107;
    border-color:#6d5300;

}

.status-aprovado{

    background:#09351f;
    color:#33d17a;
    border-color:#126c40;

}

.status-separando{

    background:#0b2f4f;
    color:#4db7ff;
    border-color:#1d5d91;

}

.status-enviado{

    background:#35235b;
    color:#a98cff;
    border-color:#6349a8;

}

.status-entrega{

    background:#4a2d08;
    color:#ffb347;
    border-color:#9d5b00;

}

.status-entregue{

    background:#123524;
    color:#67e8a3;
    border-color:#2e8b57;

}

.status-cancelado{

    background:#3b1015;
    color:#ff7b86;
    border-color:#b83242;

}

.table-produtos{

width:100%;
border-collapse:collapse;
margin-top:15px;

}

.table-produtos th{

background:#171717;
padding:16px;
color:#fff;

}

.table-produtos td{

padding:15px;
border-bottom:1px solid #2d2d2d;
color:#ddd;

}

.table-produtos tr:hover{

background:#222;

}

.total{

font-size:26px;
font-weight:bold;
color:#27d160;

}

select{

width:100%;

height:45px;

padding:0 14px;

background:#202020;

border:1px solid #333;

border-radius:10px;

color:#fff;

margin-top:10px;

margin-bottom:18px;

}
.card .btn{

    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;

    height:42px;

    padding:0 18px;

    background:#d90429;

    border:none;

    border-radius:8px;

    color:#fff;

    font-size:14px;

    font-weight:600;

    box-shadow:none;

    transition:.2s;

}

.card .btn:hover{

    background:#b70020;

    transform:translateY(-1px);

}

</style>

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div class="topo">

<div>

<h1>

Pedido #<?= $pedido["codigo"] ?>

</h1>

<p class="data">

Criado em <?= date("d/m/Y H:i",strtotime($pedido["criado_em"])) ?>

</p>

</div>

<a href="index.php" class="btn">

<i class="fa-solid fa-arrow-left"></i>

Voltar aos Pedidos

</a>

</div>
<div class="grid">

    <div class="card">

        <h2>
            <i class="fa-solid fa-user"></i>
            Cliente
        </h2>

        <p><strong>Nome:</strong> <?= htmlspecialchars($pedido["nome"] . " " . $pedido["sobrenome"]) ?></p>

        <p><strong>E-mail:</strong> <?= htmlspecialchars($pedido["email"]) ?></p>

        <p style="margin-top:18px;">

            <span class="badge <?= $classe ?>">

                <?= htmlspecialchars($pedido["status"]) ?>

            </span>

        </p>

    </div>

    <div class="card">

        <h2>

            <i class="fa-solid fa-receipt"></i>

            Resumo Financeiro

        </h2>

        <p>

            Subtotal

            <strong style="float:right;">

                R$ <?= number_format($pedido["subtotal"],2,",",".") ?>

            </strong>

        </p>

        <p>

            Frete

            <strong style="float:right;">

                R$ <?= number_format($pedido["frete"],2,",",".") ?>

            </strong>

        </p>

        <p>

            Desconto

            <strong style="float:right;">

                R$ <?= number_format($pedido["desconto"],2,",",".") ?>

            </strong>

        </p>

        <hr style="margin:18px 0;border:none;border-top:1px solid #333;">

        <div class="total">

            Total

            <span style="float:right;">

                R$ <?= number_format($pedido["total"],2,",",".") ?>

            </span>

        </div>

    </div>

</div>

<div class="card">

<h2>

<i class="fa-solid fa-box"></i>

Produtos do Pedido

</h2>

<table class="table-produtos">

<tr>

<th>Produto</th>

<th>Qtd.</th>

<th>Valor Unit.</th>

<th>Subtotal</th>

</tr>

<?php while($item=mysqli_fetch_assoc($itens)){ ?>

<tr>

<td>

<?= htmlspecialchars($item["nome"]) ?>

</td>

<td>

<?= $item["quantidade"] ?>

</td>

<td>

R$ <?= number_format($item["preco_unitario"],2,",",".") ?>

</td>

<td>

<strong>

R$ <?= number_format($item["subtotal"],2,",",".") ?>

</strong>

</td>

</tr>

<?php } ?>

</table>

</div>

<br>

<div class="card">

<h2>

<i class="fa-solid fa-truck-fast"></i>

Atualizar Status

</h2>

<form action="atualizar_status.php" method="POST">

<input
type="hidden"
name="id"
value="<?= $pedido["id"] ?>">

<select name="status">

<?php

$status=[

"Aguardando Pagamento",
"Pagamento Aprovado",
"Separando Pedido",
"Enviado",
"Saiu para Entrega",
"Entregue",
"Cancelado"

];

foreach($status as $s){

?>

<option
value="<?= $s ?>"
<?= $pedido["status"]==$s?"selected":"" ?>>

<?= $s ?>

</option>

<?php } ?>

</select>

<button type="submit" class="btn">

<span>Salvar Alteração</span>

</button>

</form>

</div>
</div>

</div>

</div>

</div>

</body>

</html>