<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

$pesquisa = "";

if(isset($_GET["pesquisa"])){
    $pesquisa = trim($_GET["pesquisa"]);
}

$sql = "SELECT
p.*,
u.nome,
u.sobrenome
FROM pedidos p
INNER JOIN usuarios u
ON u.id = p.usuario_id";

if($pesquisa != ""){

    $pesquisaBanco = mysqli_real_escape_string($conn,$pesquisa);

    $sql .= " WHERE
    p.codigo LIKE '%$pesquisaBanco%'
    OR u.nome LIKE '%$pesquisaBanco%'
    OR u.sobrenome LIKE '%$pesquisaBanco%'";

}

$sql .= " ORDER BY p.id DESC";

$resultado = mysqli_query($conn,$sql);

$totalPedidos = mysqli_num_rows($resultado);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Pedidos</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.topo-lista{

display:flex;
justify-content:space-between;
align-items:center;
flex-wrap:wrap;
gap:20px;
margin-bottom:30px;

}

.topo-lista h1{

color:#fff;
font-size:30px;
margin-bottom:6px;

}

.info-produtos{

color:#9f9f9f;
font-size:14px;

}

.acoes{

display:flex;
align-items:center;
gap:12px;

}

.form-pesquisa{
    display:flex;
    align-items:center;
    height:50px;
    padding:0;
    background:#181818;
    border:1px solid #2d2d2d;
    border-radius:12px;
    overflow:hidden;
}

.form-pesquisa input{
    width:250px;
    height:100%;
    padding:0 16px;
    border:none;
    outline:none;
    background:#181818;
    color:#fff;
    font-size:14px;
}

.form-pesquisa input::placeholder{
    color:#777;
}

.form-pesquisa button{
    width:50px;
    height:50px;
    border:none;
    background:#d90429;
    color:#fff;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-shrink:0;
}

.table-produtos{

width:100%;

border-collapse:collapse;

overflow:hidden;

background:#1b1b1b;

border-radius:14px;

}

.table-produtos th{

background:#171717;

padding:18px;

color:#fff;

font-size:14px;

}

.table-produtos td{

padding:16px;

border-bottom:1px solid #2d2d2d;

color:#ddd;

vertical-align:middle;

}

.table-produtos tr:hover{

background:#222;

}

.badge{

display:inline-flex;

align-items:center;

gap:8px;

padding:8px 14px;

border-radius:40px;

font-size:12px;

font-weight:700;

white-space:nowrap;

}

.status-pendente{

background:#ffb000;

color:#111;

}

.status-aprovado{

background:#00b050;

color:#fff;

}

.status-separando{

background:#0099ff;

color:#fff;

}

.status-enviado{

background:#5f3dc4;

color:#fff;

}

.status-entrega{

background:#ff7300;

color:#fff;

}

.status-entregue{

background:#00c47a;

color:#fff;

}

.status-cancelado{

background:#d90429;

color:#fff;

}

.btn-acao{

display:inline-flex;

align-items:center;

justify-content:center;

width:40px;

height:40px;

border-radius:8px;

text-decoration:none;

color:#fff;

transition:.25s;

}

.btn-acao.editar{

background:#0b84ff;

}

.btn-acao.editar:hover{

transform:translateY(-2px);

background:#0067cc;

}

.codigo{

font-weight:bold;

font-size:15px;

color:#fff;

}

.cliente{

font-weight:600;

color:#fff;

}

.total{

font-weight:bold;

font-size:15px;

color:#27d160;

}

</style>

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div class="topo-lista">

<div>

<h1>Pedidos</h1>

<p class="info-produtos">

<?= $totalPedidos ?> pedido(s) encontrado(s)

</p>

</div>

<div class="acoes">

<form class="form-pesquisa" method="GET">

<input
type="text"
name="pesquisa"
placeholder="Pesquisar pedido"
value="<?= htmlspecialchars($pesquisa) ?>">

<button type="submit">

<i class="fa-solid fa-magnifying-glass"></i>

</button>

</form>

</div>

</div>

<table class="table-produtos">

<tr>

<th>Código</th>

<th>Cliente</th>

<th>Pagamento</th>

<th>Total</th>

<th>Status</th>

<th width="100">Ações</th>

</tr>

<?php while($pedido = mysqli_fetch_assoc($resultado)){ ?>

<?php

switch($pedido["status"]){

case "Aguardando Pagamento":

$classe="status-pendente";

$icone="fa-clock";

break;

case "Pagamento Aprovado":

$classe="status-aprovado";

$icone="fa-circle-check";

break;

case "Separando Pedido":

$classe="status-separando";

$icone="fa-box-open";

break;

case "Enviado":

$classe="status-enviado";

$icone="fa-truck";

break;

case "Saiu para Entrega":

$classe="status-entrega";

$icone="fa-truck-fast";

break;

case "Entregue":

$classe="status-entregue";

$icone="fa-circle-check";

break;

default:

$classe="status-cancelado";

$icone="fa-circle-xmark";

}

?>

<tr>

<td>

<div class="codigo">

#<?= htmlspecialchars($pedido["codigo"]) ?>

</div>

</td>

<td>

<div class="cliente">

<?= htmlspecialchars($pedido["nome"] . " " . $pedido["sobrenome"]) ?>

</div>

</td>

<td>

<?= htmlspecialchars($pedido["forma_pagamento"]) ?>

</td>

<td>

<div class="total">

R$ <?= number_format($pedido["total"],2,",",".") ?>

</div>

</td>

<td>

<span class="badge <?= $classe ?>">

<i class="fa-solid <?= $icone ?>"></i>

<?= htmlspecialchars($pedido["status"]) ?>

</span>

</td>

<td>

<a
href="visualizar.php?id=<?= $pedido["id"] ?>"
class="btn-acao editar"
title="Visualizar Pedido">

<i class="fa-solid fa-eye"></i>

</a>

</td>

</tr>

<?php } ?>

</table>

<?php if($totalPedidos == 0){ ?>

<div style="

margin-top:35px;

padding:40px;

background:#1b1b1b;

border-radius:14px;

text-align:center;

">

<i
class="fa-solid fa-cart-shopping"
style="font-size:60px;color:#444;margin-bottom:20px;">

</i>

<h2
style="color:#fff;margin-bottom:12px;">

Nenhum pedido encontrado

</h2>

<p
style="color:#999;">

Os pedidos realizados na loja aparecerão aqui automaticamente.

</p>

</div>

<?php } ?>

</div>

</div>

</div>

</body>

</html>