<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

if($_SERVER["REQUEST_METHOD"] != "POST"){
    header("Location: index.php");
    exit();
}

$id = (int)$_POST["id"];
$status = trim($_POST["status"]);

/* Busca status atual */

$sql = "SELECT status FROM pedidos WHERE id = ?";

$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)==0){
    header("Location:index.php");
    exit();
}

$pedido = mysqli_fetch_assoc($resultado);

$statusAnterior = $pedido["status"];

/* Atualiza status */

$sql = "UPDATE pedidos
SET status = ?
WHERE id = ?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"si",$status,$id);

mysqli_stmt_execute($stmt);

/*
=========================================
BAIXA AUTOMÁTICA DO ESTOQUE
=========================================
*/

if(
    $status == "Pagamento Aprovado"
    &&
    $statusAnterior != "Pagamento Aprovado"
){

    $itens = mysqli_query($conn,"
    SELECT
    produto_id,
    quantidade
    FROM itens_pedido
    WHERE pedido_id = $id
    ");

    while($item = mysqli_fetch_assoc($itens)){

        mysqli_query($conn,"
        UPDATE produtos
        SET

        estoque = estoque - {$item["quantidade"]},

        vendas = vendas + {$item["quantidade"]}

        WHERE id = {$item["produto_id"]}
        ");

    }

}

header("Location: visualizar.php?id=".$id);
exit();