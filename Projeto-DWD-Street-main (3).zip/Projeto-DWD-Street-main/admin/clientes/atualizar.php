<?php

include("../../config/conexao.php");
include("../includes/verifica_login.php");

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location:index.php");
    exit();
}

$id = (int)$_POST["id"];

$nome = trim($_POST["nome"]);
$sobrenome = trim($_POST["sobrenome"]);
$email = trim($_POST["email"]);
$telefone = trim($_POST["telefone"]);
$cpf = trim($_POST["cpf"]);
$nivel = $_POST["nivel"];

/* Verifica se já existe outro usuário com o mesmo e-mail */

$sql = "SELECT id
        FROM usuarios
        WHERE email=?
        AND id<>?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"si",$email,$id);

mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)>0){

    header("Location:editar.php?id=".$id."&email=1");
    exit();

}

/* Verifica CPF duplicado */

$sql = "SELECT id
        FROM usuarios
        WHERE cpf=?
        AND id<>?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"si",$cpf,$id);

mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)>0){

    header("Location:editar.php?id=".$id."&cpf=1");
    exit();

}

/* Atualiza */

$sql = "UPDATE usuarios
        SET
            nome=?,
            sobrenome=?,
            email=?,
            telefone=?,
            cpf=?,
            nivel=?
        WHERE id=?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(

    $stmt,

    "ssssssi",

    $nome,
    $sobrenome,
    $email,
    $telefone,
    $cpf,
    $nivel,
    $id

);

if(mysqli_stmt_execute($stmt)){

    header("Location:index.php?sucesso=1");
    exit();

}else{

    die("Erro ao atualizar cliente: ".mysqli_error($conn));

}