<?php
session_start();

include("../../config/conexao.php");
include("../includes/verifica_login.php");

if(!isset($_GET["id"])){
    header("Location:index.php");
    exit();
}

$id = (int)$_GET["id"];

$stmt = mysqli_prepare($conn,"SELECT * FROM usuarios WHERE id=?");
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)==0){
    die("Cliente não encontrado.");
}

$cliente = mysqli_fetch_assoc($resultado);

$totalPedidos = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) total
FROM pedidos
WHERE usuario_id=".$cliente['id']))['total'];

$totalGasto = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT IFNULL(SUM(total),0) total
FROM pedidos
WHERE usuario_id=".$cliente['id']))['total'];

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Editar Cliente</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.topo{

display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:30px;
flex-wrap:wrap;
gap:20px;

}

.topo h1{

font-size:30px;
color:#fff;

}

.data{

color:#888;
margin-top:6px;

}

.grid{

display:grid;
grid-template-columns:1fr 1fr;
gap:20px;
margin-bottom:25px;

}

.card{

background:#1b1b1b;
border:1px solid #2d2d2d;
border-radius:14px;
padding:25px;

}

.card h2{

color:#fff;
font-size:18px;
margin-bottom:18px;
padding-bottom:12px;
border-bottom:1px solid #2d2d2d;

}

.card h2 i{

margin-right:8px;
color:#d90429;

}

.card p{

color:#ddd;
margin-bottom:12px;

}

.valor{

font-size:22px;
font-weight:bold;
color:#2ecc71;

}

.badge{

display:inline-block;
padding:7px 14px;
border-radius:20px;
font-size:13px;
font-weight:bold;

}

.ativo{

background:#198754;
color:#fff;

}

.inativo{

background:#dc3545;
color:#fff;

}

.admin{

background:#d90429;
color:#fff;

}

.cliente{

background:#0d6efd;
color:#fff;

}

.btnVoltar{

display:inline-flex;
align-items:center;
gap:8px;

padding:10px 18px;

background:#1b1b1b;

border:1px solid #2d2d2d;

border-radius:10px;

color:#fff;

text-decoration:none;

font-weight:600;

transition:.2s;

}

.btnVoltar:hover{

background:#242424;

}

.formulario{

background:#1b1b1b;
border:1px solid #2d2d2d;
border-radius:14px;
padding:30px;

}

.form-grid{

display:grid;
grid-template-columns:1fr 1fr;
gap:20px;

}

.grupo{

margin-bottom:20px;

}

.grupo label{

display:block;
margin-bottom:8px;
font-weight:600;
color:#fff;

}

.grupo input,
.grupo select{

width:100%;
height:48px;

padding:0 15px;

background:#121212;

border:1px solid #333;

border-radius:10px;

color:#fff;

outline:none;

transition:.2s;

}

.grupo input:focus,
.grupo select:focus{

border-color:#d90429;

}

.btnSalvar{

margin-top:15px;

display:inline-flex;
align-items:center;
justify-content:center;
gap:10px;

height:46px;

padding:0 26px;

background:#d90429;

border:none;

border-radius:10px;

color:#fff;

font-weight:600;

cursor:pointer;

transition:.2s;

}

.btnSalvar:hover{

background:#b80022;

}

</style>

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div class="topo">

<div>

<h1>Editar Cliente</h1>

<p class="data">

Edite as informações do usuário.

</p>

</div>

<a href="index.php" class="btnVoltar">

<i class="fa-solid fa-arrow-left"></i>

Voltar aos Clientes

</a>

</div>

<div class="grid">

<div class="card">

<h2>

<i class="fa-solid fa-user"></i>

Informações

</h2>

<p>

<strong>Cadastro:</strong>

<?= !empty($cliente["criado_em"]) ? date("d/m/Y",strtotime($cliente["criado_em"])) : "Não informado"; ?>

</p>

<p>

<strong>Status:</strong>

<?php if(isset($cliente["status"]) && $cliente["status"]=="ativo"){ ?>

<span class="badge ativo">Ativo</span>

<?php }else{ ?>

<span class="badge inativo">Inativo</span>

<?php } ?>

</p>

<p>

<strong>Nível:</strong>

<?php if($cliente["nivel"]=="admin"){ ?>

<span class="badge admin">Administrador</span>

<?php }else{ ?>

<span class="badge cliente">Cliente</span>

<?php } ?>

</p>

</div>

<div class="card">

<h2>

<i class="fa-solid fa-cart-shopping"></i>

Resumo

</h2>

<p><strong>Pedidos:</strong> <?= $totalPedidos ?></p>

<p>

<strong>Total Gasto:</strong>

<span class="valor">

R$ <?= number_format($totalGasto,2,",",".") ?>

</span>

</p>

</div>

</div>

<form action="atualizar.php" method="POST" class="formulario">

<input type="hidden" name="id" value="<?= $cliente["id"] ?>">

<div class="form-grid">

<div class="grupo">

<label>Nome</label>

<input
type="text"
name="nome"
value="<?= htmlspecialchars($cliente["nome"]) ?>"
required>

</div>

<div class="grupo">

<label>Sobrenome</label>

<input
type="text"
name="sobrenome"
value="<?= htmlspecialchars($cliente["sobrenome"]) ?>"
required>

</div>

<div class="grupo">

<label>Email</label>

<input
type="email"
name="email"
value="<?= htmlspecialchars($cliente["email"]) ?>"
required>

</div>

<div class="grupo">

<label>Telefone</label>

<input
type="text"
name="telefone"
value="<?= htmlspecialchars($cliente["telefone"]) ?>">

</div>

<div class="grupo">

<label>CPF</label>

<input
type="text"
name="cpf"
value="<?= htmlspecialchars($cliente["cpf"]) ?>"
required>

</div>

<div class="grupo">

<label>Nível</label>

<select name="nivel">

<option
value="cliente"
<?= $cliente["nivel"]=="cliente" ? "selected" : ""; ?>>

Cliente

</option>

<option
value="admin"
<?= $cliente["nivel"]=="admin" ? "selected" : ""; ?>>

Administrador

</option>

</select>

</div>

</div>

<button
type="submit"
class="btnSalvar">

<i class="fa-solid fa-floppy-disk"></i>

Salvar Alterações

</button>

</form>

</div>

</div>

</div>

</body>

</html>