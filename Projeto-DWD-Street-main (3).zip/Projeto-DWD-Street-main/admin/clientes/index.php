<?php
session_start();

include("../../config/conexao.php");
include("../includes/verificar_login.php");

$pesquisa = "";

if(isset($_GET["pesquisa"])){
    $pesquisa = mysqli_real_escape_string($conn, trim($_GET["pesquisa"]));
}

$sql = "SELECT
usuarios.*,
COUNT(pedidos.id) AS pedidos,
IFNULL(SUM(pedidos.total),0) AS total_gasto
FROM usuarios
LEFT JOIN pedidos
ON pedidos.usuario_id = usuarios.id";

if($pesquisa != ""){
    $sql .= " WHERE
    usuarios.nome LIKE '%$pesquisa%'
    OR usuarios.email LIKE '%$pesquisa%'
    OR usuarios.cpf LIKE '%$pesquisa%'";
}

$sql .= "
GROUP BY usuarios.id
ORDER BY usuarios.id DESC";

$resultado = mysqli_query($conn,$sql);

$totalClientes = mysqli_num_rows($resultado);
?>

<!DOCTYPE html>

<html lang="pt-br">

<head>

<meta charset="UTF-8">

<title>Clientes</title>

<link rel="stylesheet" href="../css/admin.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

.topo{

display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
flex-wrap:wrap;
gap:20px;

}

.topo h1{

color:#fff;
font-size:30px;

}

.info{

color:#888;
margin-top:6px;

}

.form-pesquisa{

display:flex;
align-items:center;
height:50px;
padding:0;
background:#181818;
border:1px solid #2d2d2d;
border-radius:12px;
overflow:hidden;

}

.form-pesquisa input{

width:260px;
height:100%;
padding:0 16px;
border:none;
outline:none;
background:#181818;
color:#fff;

}

.form-pesquisa input::placeholder{

color:#777;

}

.form-pesquisa button{

width:50px;
height:50px;
border:none;
background:#d90429;
color:#fff;
cursor:pointer;
display:flex;
align-items:center;
justify-content:center;

}

.table-clientes{

width:100%;
border-collapse:collapse;
background:#1b1b1b;
border-radius:12px;
overflow:hidden;

}

.table-clientes th{

background:#151515;
padding:16px;
color:#fff;

}

.table-clientes td{

padding:16px;
color:#ddd;
border-bottom:1px solid #2d2d2d;
vertical-align:middle;

}

.table-clientes tr:hover{

background:#222;

}

.nome{

font-weight:bold;
font-size:15px;
color:#fff;

}

.email{

font-size:13px;
color:#888;
margin-top:4px;

}

.badge{

display:inline-block;
padding:6px 12px;
border-radius:30px;
font-size:12px;
font-weight:bold;

}

.admin{

background:#d90429;
color:#fff;

}

.cliente{

background:#0f7b37;
color:#fff;

}

.ativo{

background:#0f7b37;
color:#fff;

}

.inativo{

background:#777;
color:#fff;

}

.valor{

font-weight:bold;
color:#27d160;

}

.btnAcao{

padding:8px 12px;
border-radius:6px;
text-decoration:none;
color:#fff;
margin-right:5px;

}

.editar{

background:#0b84ff;

}

.excluir{

background:#d90429;

}

</style>

</head>

<body>

<div class="container">

<?php include("../includes/menu.php"); ?>

<div class="main">

<?php include("../includes/topbar.php"); ?>

<div class="conteudo">

<div class="topo">

<div>

<h1>Clientes</h1>

<p class="info">

<?= $totalClientes ?> usuário(s) encontrado(s)

</p>

</div>

<form class="form-pesquisa" method="GET">

<input
type="text"
name="pesquisa"
placeholder="Pesquisar cliente..."
value="<?= htmlspecialchars($pesquisa) ?>">

<button>

<i class="fa-solid fa-magnifying-glass"></i>

</button>

</form>

</div>

<table class="table-clientes">

<tr>

<th>Cliente</th>

<th>CPF</th>

<th>Pedidos</th>

<th>Total Gasto</th>

<th>Nível</th>

<th>Status</th>

<th width="150">Ações</th>

</tr>
<?php while($cliente = mysqli_fetch_assoc($resultado)){ ?>

<tr>

<td>

<div class="nome">

<?= htmlspecialchars($cliente["nome"]) ?>

<?php if(!empty($cliente["sobrenome"])){ ?>

<?= htmlspecialchars($cliente["sobrenome"]) ?>

<?php } ?>

</div>

<div class="email">

<?= htmlspecialchars($cliente["email"]) ?>

<?php if(!empty($cliente["telefone"])){ ?>

<br>

<?= htmlspecialchars($cliente["telefone"]) ?>

<?php } ?>

</div>

</td>

<td>

<?php if(!empty($cliente["cpf"])){ ?>

<?= htmlspecialchars($cliente["cpf"]) ?>

<?php }else{ ?>

<span style="color:#666;">Não informado</span>

<?php } ?>

</td>

<td>

<span class="badge" style="background:#2b2b2b;color:#fff;">

<?= $cliente["pedidos"] ?>

Pedido(s)

</span>

</td>

<td>

<span class="valor">

R$ <?= number_format($cliente["total_gasto"],2,",",".") ?>

</span>

</td>

<td>

<?php if($cliente["nivel"] == "admin"){ ?>

<span class="badge admin">

Administrador

</span>

<?php }else{ ?>

<span class="badge cliente">

Cliente

</span>

<?php } ?>

</td>

<td>

<?php if($cliente["status"] == "ativo"){ ?>

<span class="badge ativo">

Ativo

</span>

<?php }else{ ?>

<span class="badge inativo">

Inativo

</span>

<?php } ?>

</td>

<td>

<a
href="editar.php?id=<?= $cliente["id"] ?>"
class="btnAcao editar">

<i class="fa-solid fa-pen"></i>

</a>

<?php if($cliente["id"] != 1){ ?>

<a
href="excluir.php?id=<?= $cliente["id"] ?>"
class="btnAcao excluir"
onclick="return confirm('Deseja excluir este usuário?')">

<i class="fa-solid fa-trash"></i>

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</table>

<?php if($totalClientes == 0){ ?>

<div style="
margin-top:30px;
padding:35px;
background:#1b1b1b;
border-radius:12px;
text-align:center;
color:#888;
">

<i class="fa-solid fa-users"
style="font-size:60px;color:#444;margin-bottom:15px;"></i>

<h2 style="color:#fff;margin-bottom:10px;">

Nenhum usuário encontrado

</h2>

<p>

Não existem clientes cadastrados.

</p>

</div>

<?php } ?>

</div>

</div>

</div>

</body>

</html>