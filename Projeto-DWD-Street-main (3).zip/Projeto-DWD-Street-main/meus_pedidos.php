<?php
session_start();
require_once "config/conexao.php";

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION["id"];

$sql = "
SELECT *
FROM pedidos
WHERE usuario_id = ?
ORDER BY criado_em DESC
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $usuario_id);
mysqli_stmt_execute($stmt);

$pedidos = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Meus Pedidos | DWD Street</title>

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700;800;900&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Montserrat',sans-serif;
}

body{

    background:#0d0d0d;
    color:#fff;

}

.container{

    width:1300px;
    max-width:95%;
    margin:45px auto 80px;

}

.topo{

    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:40px;
    flex-wrap:wrap;
    gap:20px;

}

.topo h1{

    font-size:48px;
    font-weight:900;

}

.voltar{

    text-decoration:none;
    background:#1d1d1d;
    color:#fff;
    padding:14px 24px;
    border-radius:12px;
    font-weight:700;
    transition:.3s;

}

.voltar:hover{

    background:#e31e24;

}

.sem-pedidos{

    background:#171717;
    border:1px solid #2c2c2c;
    border-radius:18px;
    padding:80px 30px;
    text-align:center;

}

.sem-pedidos h2{

    font-size:32px;
    margin-bottom:15px;

}

.sem-pedidos p{

    color:#999;
    margin-bottom:30px;

}

.btn-comprar{

    display:inline-block;
    text-decoration:none;
    background:#e31e24;
    color:#fff;
    padding:15px 35px;
    border-radius:10px;
    font-weight:700;

}

.lista{

    display:flex;
    flex-direction:column;
    gap:30px;

}

.card{

    background:#171717;
    border:1px solid #2c2c2c;
    border-radius:18px;
    padding:28px;

}
.card-topo{

    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    flex-wrap:wrap;
    margin-bottom:30px;

}

.codigo{

    font-size:28px;
    font-weight:900;

}

.data{

    margin-top:6px;
    color:#8d8d8d;
    font-size:14px;

}

.status{

    padding:10px 18px;
    border-radius:30px;
    font-size:14px;
    font-weight:700;
    color:#fff;

}

.aguardando{
    background:#d97706;
}

.aprovado{
    background:#16a34a;
}

.separando{
    background:#2563eb;
}

.enviado{
    background:#7c3aed;
}

.entrega{
    background:#0891b2;
}

.entregue{
    background:#22c55e;
}

.cancelado{
    background:#dc2626;
}

.info{

    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
    margin-bottom:35px;

}

.box{

    background:#202020;
    border-radius:14px;
    padding:18px;

}

.box span{

    display:block;
    color:#888;
    font-size:13px;
    text-transform:uppercase;
    margin-bottom:8px;

}

.box strong{

    font-size:22px;
    font-weight:800;

}

.progresso{

    position:relative;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin:35px 0;

}

.progresso::before{

    content:"";
    position:absolute;
    left:0;
    right:0;
    top:22px;
    height:4px;
    background:#323232;
    z-index:1;

}

.etapa{

    position:relative;
    z-index:2;
    display:flex;
    flex-direction:column;
    align-items:center;
    width:16%;

}

.numero{

    width:42px;
    height:42px;
    border-radius:50%;
    background:#3a3a3a;
    display:flex;
    justify-content:center;
    align-items:center;
    color:#fff;
    font-weight:800;
    margin-bottom:10px;

}

.numero.ativo{

    background:#e31e24;

}

.nome-etapa{

    color:#bcbcbc;
    font-size:13px;
    text-align:center;

}

.rodape{

    display:flex;
    justify-content:flex-end;
    margin-top:20px;

}

.btn-detalhes{

    text-decoration:none;
    background:#e31e24;
    color:#fff;
    padding:14px 28px;
    border-radius:12px;
    font-weight:700;
    transition:.3s;

}

.btn-detalhes:hover{

    transform:translateY(-2px);
    background:#ff2d34;

}

@media(max-width:900px){

.info{

grid-template-columns:1fr;

}

.card-topo{

flex-direction:column;
align-items:flex-start;

}

.progresso{

overflow-x:auto;
padding-bottom:10px;

}

.progresso::before{

min-width:700px;

}

.etapa{

min-width:120px;

}

}
</style>

</head>

<body>

<div class="container">

<div class="topo">

<h1>Meus Pedidos</h1>

<a href="index.php" class="voltar">
← Voltar à loja
</a>

</div>
<?php if(mysqli_num_rows($pedidos) == 0){ ?>

<div class="sem-pedidos">

    <h2>Você ainda não possui pedidos.</h2>

    <p>
        Quando você finalizar uma compra ela aparecerá aqui.
    </p>

    <a href="index.php" class="btn-comprar">
        Continuar comprando
    </a>

</div>

<?php }else{ ?>

<div class="lista">

<?php while($pedido = mysqli_fetch_assoc($pedidos)){ ?>

<?php

$status = $pedido["status"];

$etapa = 1;

switch($status){

    case "Aguardando Pagamento":
        $etapa = 1;
    break;

    case "Pagamento Aprovado":
        $etapa = 2;
    break;

    case "Separando Pedido":
        $etapa = 3;
    break;

    case "Enviado":
        $etapa = 4;
    break;

    case "Saiu para Entrega":
        $etapa = 5;
    break;

    case "Entregue":
        $etapa = 6;
    break;

    case "Cancelado":
        $etapa = 0;
    break;

}

$statusClasse = "aguardando";

if($status=="Pagamento Aprovado") $statusClasse="aprovado";
if($status=="Separando Pedido") $statusClasse="separando";
if($status=="Enviado") $statusClasse="enviado";
if($status=="Saiu para Entrega") $statusClasse="entrega";
if($status=="Entregue") $statusClasse="entregue";
if($status=="Cancelado") $statusClasse="cancelado";

?>

<div class="card">

<div class="card-topo">

<div>

<div class="codigo">

Pedido #<?= $pedido["codigo"] ?>

</div>

<div class="data">

<?= date("d/m/Y H:i",strtotime($pedido["criado_em"])) ?>

</div>

</div>

<div class="status <?= $statusClasse ?>">

<?= $status ?>

</div>

</div>

<div class="info">

<div class="box">

<span>Total</span>

<strong>

R$ <?= number_format($pedido["total"],2,",",".") ?>

</strong>

</div>

<div class="box">

<span>Pagamento</span>

<strong>

<?= $pedido["forma_pagamento"] ?>

</strong>

</div>

<div class="box">

<span>Código</span>

<strong>

<?= $pedido["codigo"] ?>

</strong>

</div>

</div>

<div class="rodape">

<a
href="detalhes_pedido.php?id=<?= $pedido["id"] ?>"
class="btn-detalhes">

Ver detalhes →

</a>

</div>

</div>

<?php } ?>

</div>

<?php } ?>

</div>

</body>
</html>