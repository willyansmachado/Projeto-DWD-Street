<?php
session_start();
include("../config/conexao.php"); 

$categoria_id = 11; // Mude esse número para o ID correto do banco!

// Busca o nome real no banco de dados
$sql_cat = "SELECT nome FROM categorias WHERE id = ? AND ativo = 1 LIMIT 1";
$stmt_cat = mysqli_prepare($conn, $sql_cat);
mysqli_stmt_bind_param($stmt_cat, "i", $categoria_id);
mysqli_stmt_execute($stmt_cat);
$resultado_cat = mysqli_stmt_get_result($stmt_cat);
$categoria_atual = mysqli_fetch_assoc($resultado_cat);

// Forçamos o título a ser "Jorts" no topo da página para ficar bonito no site
$nome_categoria = "Jóias";

// Busca os produtos
$sql = "SELECT p.*, c.nome AS nome_categoria 
        FROM produtos p 
        INNER JOIN categorias c ON c.id = p.categoria_id 
        WHERE p.categoria_id = ? AND p.ativo = 1 
        ORDER BY p.id DESC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $categoria_id);
mysqli_stmt_execute($stmt);
$resultado_produtos = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($nome_categoria) ?> - DWD Street</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root { --brand-red: #d90429; --brand-red-hover: #b80022; --bg-main: #0b0b0b; --bg-card: #161616; --border-color: #222222; --border-hover: #333333; --text-light: #ffffff; --text-muted: #888888; }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Montserrat', sans-serif; background: var(--bg-main); color: var(--text-light); -webkit-font-smoothing: antialiased; }
        a { text-decoration: none; color: inherit; }
        .top-bar { background: #000000; color: var(--text-light); text-align: center; padding: 12px 20px; font-size: 11px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; border-bottom: 1px solid var(--border-color); }
        header { background: rgba(0, 0, 0, 0.85); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); padding: 20px 5%; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 100; border-bottom: 1px solid var(--border-color); }
        .logo { font-weight: 900; font-size: 1.6rem; letter-spacing: -1.5px; font-style: italic; text-transform: uppercase; }
        .logo-dwd { color: #ffffff; } .logo-street { color: var(--brand-red); }
        .btn-inicio { color: var(--text-light); font-weight: 700; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; border: 1px solid #333; padding: 10px 20px; border-radius: 4px; transition: all 0.2s ease-in-out; }
        .btn-inicio:hover { background: var(--text-light); color: #000000; border-color: var(--text-light); }
        .category-hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.9)); text-align: center; padding: 80px 20px; border-bottom: 1px solid var(--border-color); }
        .category-hero h1 { font-size: 3.5rem; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 15px; font-style: italic; }
        .category-hero p { color: var(--text-muted); font-size: 13px; font-weight: 500; letter-spacing: 0.8px; max-width: 600px; margin: 0 auto; text-transform: uppercase; }
        .shop-container { max-width: 1300px; margin: auto; padding: 40px 4%; }
        .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 40px 24px; }
        .product-card { background: var(--bg-card); border-radius: 8px; overflow: hidden; position: relative; display: flex; flex-direction: column; border: 1px solid var(--border-color); transition: transform 0.3s ease, border-color 0.3s ease; }
        .product-card:hover { transform: translateY(-5px); border-color: var(--border-hover); }
        .product-badge { position: absolute; top: 15px; left: 15px; background: var(--brand-red); color: #ffffff; font-size: 10px; font-weight: 800; padding: 4px 10px; text-transform: uppercase; letter-spacing: 1px; z-index: 5; border-radius: 4px; }
        .product-img-holder { width: 100%; height: 340px; background: #111; overflow: hidden; display: flex; align-items: center; justify-content: center; border-bottom: 1px solid var(--border-color); }
        .product-img-holder img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; }
        .product-card:hover .product-img-holder img { transform: scale(1.05); }
        .product-info { padding: 20px; display: flex; flex-direction: column; flex-grow: 1; }
        .product-category { font-size: 10px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; letter-spacing: 1px; margin-bottom: 6px; }
        .product-title { font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; line-height: 1.4; color: var(--text-light); min-height: 40px; }
        .product-price-box { margin-top: auto; margin-bottom: 15px; }
        .old-price { font-size: 11px; color: var(--text-muted); text-decoration: line-through; margin-bottom: 2px; display: block; }
        .current-price { font-size: 18px; font-weight: 800; color: var(--text-light); }
        .price-parcelas { font-size: 11px; color: var(--text-muted); margin-top: 2px; display: block; }
        .btn-add-cart { background: transparent; color: var(--text-light); border: 1px solid #333; padding: 12px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; cursor: pointer; width: 100%; border-radius: 4px; transition: all 0.2s ease-in-out; text-align: center; display: block; }
        .btn-add-cart:hover { background: var(--brand-red); color: #ffffff; border-color: var(--brand-red); }
        .no-products { grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--text-muted); border: 1px dashed var(--border-color); text-transform: uppercase; font-size: 12px; letter-spacing: 1.5px; border-radius: 8px; }
        footer { background: #000000; border-top: 2px solid var(--border-color); padding: 60px 5% 30px; margin-top: 80px; }
        .footer-bottom { text-align: center; font-size: 11px; color: #555; font-weight: 600; }
    </style>
</head>
<body>
    <div class="top-bar">Entrega rápida em toda Joinville</div>
    <header>
        <div class="logo"><span class="logo-dwd">DWD</span><span class="logo-street">STREET</span></div>
        <nav><a href="../index.php" class="btn-inicio">⬅ Voltar ao Início</a></nav>
    </header>

    <section class="category-hero">
        <h1><?= htmlspecialchars($nome_categoria) ?></h1>
        <p>Corte street e caimento perfeito para o seu estilo urbano</p>
    </section>

    <main class="shop-container">
        <div class="products-grid">
            <?php 
            if (mysqli_num_rows($resultado_produtos) > 0):
                while ($item = mysqli_fetch_assoc($resultado_produtos)): 
                    $badgeText = ($item['lancamento'] == 1) ? "Novo" : (($item['destaque'] == 1) ? "Destaque" : "");
                    $temPromo = !empty($item['preco_promocional']);
                    $precoExibido = $temPromo ? $item['preco_promocional'] : $item['preco'];
                    $valorParcela = $precoExibido / 3;
                    $imagemProduto = !empty($item['imagem']) ? "../" . $item['imagem'] : "../admin/img/sem-imagem.png";
            ?>
            <div class="product-card">
                <?php if (!empty($badgeText)): ?><div class="product-badge"><?= $badgeText ?></div><?php endif; ?>
                <div class="product-img-holder"><img src="<?= htmlspecialchars($imagemProduto) ?>"></div>
                <div class="product-info">
                    <span class="product-category"><?= htmlspecialchars($item['nome_categoria']) ?></span>
                    <h2 class="product-title"><?= htmlspecialchars($item['nome']) ?></h2>
                    <div class="product-price-box">
                        <?php if ($temPromo): ?><span class="old-price">R$ <?= number_format($item['preco'], 2, ',', '.') ?></span><?php endif; ?>
                        <span class="current-price">R$ <?= number_format($precoExibido, 2, ',', '.') ?></span>
                    </div>
                    <a href="../carrinho.php?acao=add&id=<?= $item['id'] ?>" class="btn-add-cart">Comprar Agora</a>
                </div>
            </div>
            <?php endwhile; else: ?>
                <div class="no-products">Nenhum produto encontrado nesta categoria.</div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>