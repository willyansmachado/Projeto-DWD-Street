<?php
session_start();
include("config/conexao.php");

if (isset($_GET['pedido'])) {
    $pedido_id = intval($_GET['pedido']);
    
    // Agora usando o nome ENUM certinho do seu banco!
    $sql = "UPDATE pedidos SET status = 'Pagamento Aprovado' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $pedido_id);
    
    if ($stmt->execute()) {
        header("Location: obrigado.php?pedido=" . $pedido_id);
        exit();
    } else {
        die("Erro ao simular pagamento: " . $conn->error);
    }
} else {
    header("Location: index.php");
    exit();
}
?>