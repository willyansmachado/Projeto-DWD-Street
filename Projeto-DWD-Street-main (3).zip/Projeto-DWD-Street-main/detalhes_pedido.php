<?php
session_start();
require_once "config/conexao.php";

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET["id"])) {
    header("Location: meus_pedidos.php");
    exit();
}

$usuario_id = $_SESSION["id"];
$pedido_id = intval($_GET["id"]);

$sql = "
SELECT *
FROM pedidos
WHERE id = ?
AND usuario_id = ?
LIMIT 1
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $pedido_id, $usuario_id);
mysqli_stmt_execute($stmt);

$resultado = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($resultado)==0){
    die("Pedido não encontrado.");
}

$pedido = mysqli_fetch_assoc($resultado);

$sqlItens = "
SELECT
pi.*,
p.nome,
p.imagem
FROM itens_pedido pi
INNER JOIN produtos p
ON p.id = pi.produto_id
WHERE pi.pedido_id=?
";

$stmtItens = mysqli_prepare($conn,$sqlItens);
mysqli_stmt_bind_param($stmtItens,"i",$pedido_id);
mysqli_stmt_execute($stmtItens);

$itens=mysqli_stmt_get_result($stmtItens);

$status=$pedido["status"];

$etapa=1;

switch($status){

case "Pagamento Aprovado":
$etapa=2;
break;

case "Separando Pedido":
$etapa=3;
break;

case "Enviado":
$etapa=4;
break;

case "Saiu para Entrega":
$etapa=5;
break;

case "Entregue":
$etapa=6;
break;

case "Cancelado":
$etapa=0;
break;

default:
$etapa=1;

}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Pedido <?php echo $pedido["codigo"]; ?> | DWD Street</title>

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700;800;900&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Montserrat,sans-serif;
}

body{

background:#0d0d0d;

color:#fff;

}

.container{

width:1300px;

max-width:95%;

margin:50px auto;

}

.topo{

display:flex;

justify-content:space-between;

align-items:center;

margin-bottom:35px;

}

.titulo{

font-size:42px;

font-weight:900;

}

.btn-voltar{

background:#1b1b1b;

padding:15px 28px;

border-radius:10px;

text-decoration:none;

color:#fff;

font-weight:700;

transition:.3s;

}

.btn-voltar:hover{

background:#e31e24;

}

.card{

background:#171717;

border:1px solid #2b2b2b;

border-radius:18px;

padding:30px;

margin-bottom:30px;

box-shadow:0 10px 30px rgba(0,0,0,.45);

}

.grid{

display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

}

.box{

background:#202020;

padding:20px;

border-radius:12px;

}

.box span{

display:block;

font-size:12px;

text-transform:uppercase;

color:#999;

margin-bottom:10px;

}

.box strong{

font-size:22px;

}

.status{

display:inline-block;

padding:10px 18px;

border-radius:50px;

font-weight:700;

font-size:14px;

}

.status.aguardando{

background:#d97706;

}

.status.aprovado{

background:#16a34a;

}

.status.separando{

background:#2563eb;

}

.status.enviado{

background:#7c3aed;

}

.status.entrega{

background:#0891b2;

}

.status.entregue{

background:#22c55e;

}

.status.cancelado{

background:#dc2626;

}

.timeline{

display:flex;

justify-content:space-between;

align-items:center;

margin-top:30px;

position:relative;

}

.timeline::before{

content:"";

position:absolute;

left:0;

right:0;

top:22px;

height:4px;

background:#2a2a2a;

z-index:0;

}

.etapa{

position:relative;

z-index:2;

display:flex;

flex-direction:column;

align-items:center;

width:16%;

}

.bola{

width:45px;

height:45px;

border-radius:50%;

background:#333;

display:flex;

justify-content:center;

align-items:center;

font-weight:800;

margin-bottom:12px;

}

.ativa{

background:#e31e24;

}

.etapa p{

font-size:13px;

text-align:center;

color:#ccc;

}

h2{

font-size:32px;

margin-bottom:25px;

font-weight:900;

}

.produto{

display:flex;

align-items:center;

justify-content:space-between;

background:#202020;

padding:20px;

border-radius:14px;

margin-bottom:20px;

transition:.3s;

}

.produto:hover{

transform:translateY(-3px);

background:#242424;

}

.produto img{

width:120px;

height:120px;

object-fit:cover;

border-radius:12px;

background:#111;

}

.info-produto{

flex:1;

padding-left:25px;

}

.info-produto h3{

font-size:24px;

margin-bottom:10px;

}

.info-produto p{

color:#aaa;

margin-bottom:6px;

}

.preco{

font-size:26px;

font-weight:900;

color:#fff;

}

</style>
<div class="container">

    <div class="topo">

        <h1 class="titulo">
            Pedido #<?php echo $pedido["codigo"]; ?>
        </h1>

        <a href="meus_pedidos.php" class="btn-voltar">
            ← Voltar aos pedidos
        </a>

    </div>

    <div class="card">

        <div class="grid">

            <div class="box">

                <span>Status</span>

                <?php

                $classe="aguardando";

                switch($pedido["status"]){

                    case "Pagamento Aprovado":
                        $classe="aprovado";
                        break;

                    case "Separando Pedido":
                        $classe="separando";
                        break;

                    case "Enviado":
                        $classe="enviado";
                        break;

                    case "Saiu para Entrega":
                        $classe="entrega";
                        break;

                    case "Entregue":
                        $classe="entregue";
                        break;

                    case "Cancelado":
                        $classe="cancelado";
                        break;

                }

                ?>

                <div class="status <?php echo $classe; ?>">
                    <?php echo $pedido["status"]; ?>
                </div>

            </div>

            <div class="box">

                <span>Pagamento</span>

                <strong>
                    <?php echo $pedido["forma_pagamento"]; ?>
                </strong>

            </div>

            <div class="box">

                <span>Data</span>

                <strong>

                <?php

                echo date(
                    "d/m/Y H:i",
                    strtotime($pedido["criado_em"])
                );

                ?>

                </strong>

            </div>

            <div class="box">

                <span>Total</span>

                <strong>

                R$
                <?php echo number_format($pedido["total"],2,",","."); ?>

                </strong>

            </div>

        </div>

        <div class="timeline">

            <div class="etapa">
                <div class="bola <?php if($etapa>=1) echo "ativa"; ?>">1</div>
                <p>Pedido</p>
            </div>

            <div class="etapa">
                <div class="bola <?php if($etapa>=2) echo "ativa"; ?>">2</div>
                <p>Pagamento</p>
            </div>

            <div class="etapa">
                <div class="bola <?php if($etapa>=3) echo "ativa"; ?>">3</div>
                <p>Separando</p>
            </div>

            <div class="etapa">
                <div class="bola <?php if($etapa>=4) echo "ativa"; ?>">4</div>
                <p>Enviado</p>
            </div>

            <div class="etapa">
                <div class="bola <?php if($etapa>=5) echo "ativa"; ?>">5</div>
                <p>Entrega</p>
            </div>

            <div class="etapa">
                <div class="bola <?php if($etapa>=6) echo "ativa"; ?>">6</div>
                <p>Concluído</p>
            </div>

        </div>

    </div>

    <div class="card">

        <h2>Produtos do Pedido</h2>
        <?php

if(mysqli_num_rows($itens)==0){

?>

<div style="text-align:center;padding:50px;color:#888;font-size:18px;">
Nenhum produto encontrado neste pedido.
</div>

<?php

}else{

while($item=mysqli_fetch_assoc($itens)){

?>

<div class="produto">

    <img
        src="uploads/produtos/<?php echo $item["imagem"]; ?>"
        alt="<?php echo $item["nome"]; ?>">

    <div class="info-produto">

        <h3>
            <?php echo $item["nome"]; ?>
        </h3>

        <?php if(!empty($item["cor_id"])){ ?>

        <p>

            <strong>Cor:</strong>

            <?php echo $item["cor_id"]; ?>

        </p>

        <?php } ?>

        <?php if(!empty($item["tamanho_id"])){ ?>

        <p>

            <strong>Tamanho:</strong>

            <?php echo $item["tamanho_id"]; ?>

        </p>

        <?php } ?>

        <p>

            <strong>Quantidade:</strong>

            <?php echo $item["quantidade"]; ?>

        </p>

        <p>

            <strong>Valor Unitário:</strong>

            R$
            <?php echo number_format($item["preco_unitario"],2,",","."); ?>

        </p>

    </div>

    <div class="preco">

        R$

        <?php

        echo number_format(
            $item["subtotal"],
            2,
            ",",
            "."
        );

        ?>

    </div>

</div>

<?php

}

}

?>

</div>

<div class="card">

<h2>

Resumo do Pedido

</h2>

<div class="grid">

<div class="box">

<span>Subtotal</span>

<strong>

R$

<?php echo number_format($pedido["subtotal"],2,",","."); ?>

</strong>

</div>

<div class="box">

<span>Frete</span>

<strong>

R$

<?php echo number_format($pedido["frete"],2,",","."); ?>

</strong>

</div>

<div class="box">

<span>Desconto</span>

<strong>

R$

<?php echo number_format($pedido["desconto"],2,",","."); ?>

</strong>

</div>

<div class="box">

<span>Total</span>

<strong style="color:#e31e24;">

R$

<?php echo number_format($pedido["total"],2,",","."); ?>

</strong>

</div>

</div>

<br>

<div class="box">

<span>Endereço de entrega</span>

<strong>

<?php

echo !empty($pedido["endereco"])
? nl2br(htmlspecialchars($pedido["endereco"]))
: "Endereço não informado.";

?>

</strong>

</div>

<br>

<div style="display:flex;gap:15px;flex-wrap:wrap;">

<a href="meus_pedidos.php" class="btn-voltar">

← Voltar aos pedidos

</a>

<a href="index.php" class="btn-voltar" style="background:#e31e24;">

Continuar comprando →

</a>

</div>
</div>

</div>

<footer style="margin-top:50px;padding:25px 0;text-align:center;color:#777;font-size:14px;">

    © <?php echo date("Y"); ?> DWD Street • Todos os direitos reservados.

</footer>

</body>

</html>