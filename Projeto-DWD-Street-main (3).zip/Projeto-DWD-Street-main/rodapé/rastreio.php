<?php
session_start();
include("../config/conexao.php");

// Inicializa variáveis de controle
$pedido_encontrado = false;
$status_atual = "";
$pedido_id = "";
$data_pedido = "";

// Verifica se o usuário enviou um código pelo formulário
if (isset($_POST['codigo_rastreio']) && !empty(trim($_POST['codigo_rastreio']))) {
    
    // Pega o código digitado removendo espaços extras
    $codigo = strtoupper(trim($_POST['codigo_rastreio']));
$codigo = str_replace("#", "", $codigo);
    

    // Busca o pedido na sua tabela usando a coluna exata: 'codigo'
    $sql = "SELECT id, status, criado_em FROM pedidos WHERE codigo = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado && $resultado->num_rows > 0) {
        $pedido = $resultado->fetch_assoc();
        $pedido_encontrado = true;
        
        // Pega os variáveis com os nomes exatos das suas colunas
        $pedido_id = $pedido['id'];
        $status_atual = $pedido['status']; 
        $data_pedido = date('d/m/Y', strtotime($pedido['criado_em'])); 
    } else {
        $erro = "Código de rastreio não encontrado. Verifique se digitou corretamente ou se o pedido já possui um código gerado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rastreio do Pedido | DWD Street</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,600;0,700;0,900;1,900&display=swap" rel="stylesheet">
    
    <style>
        * { box-sizing: border-box; font-family: 'Montserrat', sans-serif; margin: 0; padding: 0; }
        body { background-color: #111111; color: #ffffff; padding-bottom: 50px; }
        
        /* HEADER PADRÃO DWD STREET */
        .navbar { background-color: #111111; padding: 20px 40px; border-bottom: 1px solid #222; display: flex; justify-content: space-between; align-items: center; }
        .logo { text-decoration: none !important; font-size: 26px; font-weight: 900; color: #ffffff; letter-spacing: -0.5px; }
        .logo span { color: #ed1c24; font-style: italic; }

        .container { max-width: 800px; margin: 50px auto; padding: 0 20px; }
        .title-page { text-align: center; font-size: 24px; font-weight: 900; margin-bottom: 40px; text-transform: uppercase; letter-spacing: 1px; }
        
        /* CARD PRINCIPAL */
        .tracking-box { background-color: #1a1a1a; padding: 40px 30px; border-radius: 6px; border: 1px solid #222; box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        
        /* FORMULÁRIO DE BUSCA */
        .search-form { display: flex; gap: 10px; margin-top: 20px; }
        .search-input { flex: 1; padding: 16px; background-color: #222222; border: 1px solid #333333; border-radius: 4px; color: #ffffff; font-size: 14px; outline: none; font-weight: 600; }
        .search-input:focus { border-color: #ed1c24; }
        .search-btn { padding: 0 30px; background-color: #ed1c24; color: #ffffff; border: none; border-radius: 4px; font-size: 14px; font-weight: 800; cursor: pointer; text-transform: uppercase; transition: background-color 0.3s; }
        .search-btn:hover { background-color: #d11820; }

        .info-header { display: flex; justify-content: space-between; border-bottom: 1px solid #333; padding-bottom: 20px; margin-bottom: 40px; font-size: 14px; color: #aaa; }
        .info-header strong { color: #fff; }

        /* TIMELINE DO RASTREIO */
        .timeline { display: flex; justify-content: space-between; position: relative; margin-bottom: 40px; }
        .timeline::before { content: ''; position: absolute; top: 20px; left: 0; width: 100%; height: 4px; background-color: #333; z-index: 1; }
        .timeline-progress { position: absolute; top: 20px; left: 0; height: 4px; background-color: #ed1c24; z-index: 2; transition: width 0.5s ease; }

        .step { position: relative; z-index: 3; text-align: center; display: flex; flex-direction: column; align-items: center; width: 25%; }
        .circle { width: 44px; height: 44px; border-radius: 50%; background-color: #222; border: 3px solid #333; display: flex; align-items: center; justify-content: center; font-size: 16px; color: #666; transition: all 0.3s ease; font-weight: bold; }
        .step-title { margin-top: 15px; font-size: 12px; font-weight: 700; text-transform: uppercase; color: #666; transition: color 0.3s; }

        /* ESTADOS ATIVOS / CONCLUÍDOS */
        .step.active .circle { background-color: #111; border-color: #ed1c24; color: #ed1c24; box-shadow: 0 0 15px rgba(237, 28, 36, 0.4); }
        .step.active .step-title { color: #fff; }
        .step.completed .circle { background-color: #ed1c24; border-color: #ed1c24; color: #fff; }

        /* HISTÓRICO */
        .tracking-status-list { margin-top: 40px; border-top: 1px dashed #333; padding-top: 30px; }
        .status-node { display: flex; gap: 20px; margin-bottom: 25px; position: relative; }
        .status-node:not(:last-child)::after { content: ''; position: absolute; top: 20px; left: 6px; width: 2px; height: calc(100% + 5px); background-color: #333; }
        
        .node-dot { width: 14px; height: 14px; border-radius: 50%; background-color: #ed1c24; margin-top: 4px; z-index: 2; }
        .node-info h4 { font-size: 14px; font-weight: 700; margin-bottom: 4px; color: #fff; }
        .node-info p { font-size: 12px; color: #888; }

        .back-btn { display: block; text-align: center; text-decoration: none; color: #888; font-size: 13px; font-weight: 600; margin-top: 30px; transition: color 0.3s; }
        .back-btn:hover { color: #fff; }
        .msg-erro { color: #ed1c24; font-weight: 600; margin-bottom: 15px; font-size: 14px; text-align: center; }
    </style>
</head>
<body>

    <header class="navbar">
        <a href="index.php" class="logo">DWD<span>STREET</span></a>
    </header>

    <main class="container">
        <h2 class="title-page">Acompanhar Pedido</h2>
        
        <div class="tracking-box">
            
            <?php if (!$pedido_encontrado): ?>
                <h3>Insira seu código de rastreamento:</h3>
                
                <?php if (isset($erro)): ?>
                    <div class="msg-erro"><?php echo $erro; ?></div>
                <?php endif; ?>

                <form action="rastreio.php" method="POST" class="search-form">
                    <input type="text" name="codigo_rastreio" placeholder="Digite o código da sua compra..." class="search-input" required>
                    <button type="submit" class="search-btn">Buscar</button>
                </form>

            <?php else: ?>
                
                <div class="info-header">
                    <div>Pedido ID: <strong>#<?php echo $pedido_id; ?></strong></div>
                    <div>Data da Compra: <strong><?php echo $data_pedido; ?></strong></div>
                </div>

                <?php
                // MAPEAMENTO DO SEU ENUM PARA A LINHA DO TEMPO
                $p_width = "0%";
                $c_ped = $c_apr = $c_cam = $c_ent = "";

                // Verifica o valor da sua coluna 'status'
                if ($status_atual == "Aguardando Pagamento") {
                    $p_width = "12.5%"; $c_ped = "active";
                } elseif ($status_atual == "Pagamento Aprovado" || $status_atual == "Separando Pedido") {
                    $p_width = "37.5%"; $c_ped = "completed"; $c_apr = "active";
                } elseif ($status_atual == "Enviado" || $status_atual == "Saiu para Entrega") {
                    $p_width = "62.5%"; $c_ped = "completed"; $c_apr = "completed"; $c_cam = "active";
                } elseif ($status_atual == "Entregue") {
                    $p_width = "100%"; $c_ped = "completed"; $c_apr = "completed"; $c_cam = "completed"; $c_ent = "completed active";
                } elseif ($status_atual == "Cancelado") {
                    // Trata caso o pedido esteja cancelado
                    $p_width = "0%";
                }
                ?>

                <?php if ($status_atual == "Cancelado"): ?>
                    <div class="msg-erro" style="font-size: 18px; margin: 20px 0;">Este pedido foi Cancelado.</div>
                <?php else: ?>

                    <div class="timeline">
                        <div class="timeline-progress" style="width: <?php echo $p_width; ?>;"></div>

                        <div class="step <?php echo $c_ped; ?>">
                            <div class="circle">✓</div>
                            <div class="step-title">Recebido</div>
                        </div>
                        <div class="step <?php echo $c_apr; ?>">
                            <div class="circle">✓</div>
                            <div class="step-title">Aprovado</div>
                        </div>
                        <div class="step <?php echo $c_cam; ?>">
                            <div class="circle">🚚</div>
                            <div class="step-title">A Caminho</div>
                        </div>
                        <div class="step <?php echo $c_ent; ?>">
                            <div class="circle">🎁</div>
                            <div class="step-title">Entregue</div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="tracking-status-list">
                    
                    <?php if($status_atual == "Entregue"): ?>
                    <div class="status-node">
                        <div class="node-dot"></div>
                        <div class="node-info">
                            <h4>Pedido Entregue</h4>
                            <p>O pacote foi entregue com sucesso no endereço cadastrado.</p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(in_array($status_atual, ["Enviado", "Saiu para Entrega", "Entregue"])): ?>
                    <div class="status-node">
                        <div class="node-dot" style="<?php echo ($status_atual != 'Enviado' && $status_atual != 'Saiu para Entrega') ? 'background-color: #444;' : ''; ?>"></div>
                        <div class="node-info">
                            <h4><?php echo ($status_atual == "Saiu para Entrega") ? "Saiu para Entrega" : "Objeto em trânsito"; ?></h4>
                            <p>O pacote foi despachado do Centro de Distribuição de Joinville/SC.</p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if(in_array($status_atual, ["Pagamento Aprovado", "Separando Pedido", "Enviado", "Saiu para Entrega", "Entregue"])): ?>
                    <div class="status-node">
                        <div class="node-dot" style="<?php echo ($status_atual != 'Pagamento Aprovado' && $status_atual != 'Separando Pedido') ? 'background-color: #444;' : ''; ?>"></div>
                        <div class="node-info">
                            <h4>Pronto para o Envio</h4>
                            <p>O pagamento foi confirmado e os seus produtos da DWD Street já foram separados e embalados.</p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="status-node">
                        <div class="node-dot" style="background-color: #444;"></div>
                        <div class="node-info">
                            <h4>Pedido Registrado</h4>
                            <p>Aguardando as confirmações padrão do gateway de pagamento.</p>
                        </div>
                    </div>

                </div>

                <a href="rastreio.php" class="back-btn" style="margin-top:40px;">← Rastrear outro objeto</a>
            <?php endif; ?>
            
        </div>

        <a href="../index.php" class="back-btn">← Voltar para a Loja</a>
    </main>

</body>
</html>