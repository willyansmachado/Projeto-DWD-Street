<?php
session_start();

include("../config/conexao.php");

$nomeUsuario = "Visitante";

if(isset($_SESSION["nome"])){
    $nomeUsuario = $_SESSION["nome"];
}

$sql = "SELECT * FROM produtos WHERE lancamento = 1 ORDER BY id DESC";
$resultado = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DROP EXCLUSIVO | DWD Street</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap" rel="stylesheet">

    <style>
        body {
            background-color: #0a0a0a !important;
            color: #ffffff !important;
        }

        .drop-nav {
            background: rgba(10, 10, 10, 0.95);
            backdrop-filter: blur(10px);
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #1a1a1a;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .drop-nav .logo-drop {
            font-size: 1.5rem;
            font-weight: 900;
            letter-spacing: 3px;
            text-transform: uppercase;
        }

        .drop-nav .logo-drop span {
            color: #e31e24;
        }

        .btn-back-premium {
            color: #888;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            padding: 10px 20px;
            border: 1px solid #222;
            border-radius: 50px;
            background: #111;
        }

        .countdown-container {
            background: linear-gradient(90deg, #e31e24, #991115);
            text-align: center;
            padding: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }

        #timer {
            font-weight: 900;
            background: rgba(0,0,0,0.3);
            padding: 3px 8px;
        }

        .drop-hero {
            padding: 140px 20px;
            text-align: center;
            background-image: linear-gradient(rgba(10,10,10,0.7), rgba(10,10,10,0.95)), url('../assets/css/img/bannerlançamentos.png');
            background-size: cover;
            background-position: center;
        }

        .drop-hero h1 {
            font-size: 4rem;
            font-weight: 900;
            text-transform: uppercase;
        }

        .glow-text {
            -webkit-text-stroke: 1px #fff;
            color: transparent;
        }

        .premium-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 40px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 80px 20px;
        }

        .premium-card {
            background: #111;
            border: 1px solid #1a1a1a;
            transition: 0.3s;
        }

        .premium-card:hover {
            transform: translateY(-10px);
            border-color: #e31e24;
        }

        .premium-img-wrapper {
            position: relative;
            aspect-ratio: 1/1;
            overflow: hidden;
        }

        .premium-img-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .premium-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: #e31e24;
            padding: 6px 12px;
            font-size: 0.7rem;
            font-weight: 900;
        }

        .stock-badge {
            position: absolute;
            bottom: 15px;
            right: 15px;
            background: rgba(0,0,0,0.8);
            color: #ffcc00;
            padding: 4px 10px;
            font-size: 0.7rem;
        }

        .premium-info {
            padding: 20px;
        }

        .premium-info h3 {
            font-size: 1.2rem;
            text-transform: uppercase;
        }

        .price-tag {
            font-size: 1.4rem;
            color: #e31e24;
            font-weight: 900;
            margin: 10px 0;
        }

        .btn-drop-buy {
            width: 100%;
            padding: 15px;
            background: #fff;
            color: #000;
            font-weight: 900;
            border: none;
            text-transform: uppercase;
        }

        .premium-card:hover .btn-drop-buy {
            background: #e31e24;
            color: #fff;
        }
    </style>
</head>

<body>

<div class="countdown-container">
    🔥 DROP EXCLUSIVO: EXPIRA EM: <span id="timer">00:14:52</span>
</div>

<header class="drop-nav">
    <div class="logo-drop">
        DWD<span>STREET</span> // LAUNCH
    </div>

    <a href="../index.php" class="btn-back-premium">← Voltar</a>
</header>

<main>

<section class="drop-hero">
    <h1>DROP <span class="glow-text">01</span></h1>
    <p>Peças limitadas sem reposição</p>
</section>

<section class="premium-grid">

<?php if(mysqli_num_rows($resultado) > 0){ ?>

    <?php while($produto = mysqli_fetch_assoc($resultado)){ ?>

        <div class="premium-card">

            <div class="premium-img-wrapper">

                <span class="premium-badge">NEW DROP</span>

                <?php if($produto['estoque'] <= 3){ ?>
                    <span class="stock-badge">
                        Apenas <?php echo $produto['estoque']; ?> restantes
                    </span>
                <?php } else { ?>
                    <span class="stock-badge">Disponível</span>
                <?php } ?>

                <img src="../<?php echo $produto['imagem']; ?>" alt="">
            </div>

            <div class="premium-info">
                <h3><?php echo $produto['nome']; ?></h3>

                <div class="price-tag">
                    R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?>
                </div>

                <form action="../adicionar_carrinho.php" method="POST">
                    <input type="hidden" name="produto_nome" value="<?php echo $produto['nome']; ?>">
                    <input type="hidden" name="preco" value="<?php echo $produto['preco']; ?>">
                    <input type="hidden" name="imagem" value="<?php echo $produto['imagem']; ?>">

                    <button class="btn-drop-buy" type="submit">
                        Garantir Peça
                    </button>
                </form>

            </div>
        </div>

    <?php } ?>

<?php } else { ?>

    <p style="text-align:center;color:#888;">
        Nenhum lançamento disponível
    </p>

<?php } ?>

</section>

</main>

<script>
function startTimer(duration, display) {
    let timer = duration, minutes, seconds;

    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = "00:" + minutes + ":" + seconds;

        if (--timer < 0) timer = duration;
    }, 1000);
}

window.onload = function () {
    let display = document.querySelector('#timer');
    startTimer(60 * 14 + 52, display);
};
</script>

</body>
</html>