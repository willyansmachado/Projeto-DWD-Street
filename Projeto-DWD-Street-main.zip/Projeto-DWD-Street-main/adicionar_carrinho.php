<?php
session_start();
include("config/conexao.php");

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit();
}

$usuario_id = $_SESSION["id"];

// Verifica se todos os dados foram enviados
if (
    !isset($_POST["produto_id"]) ||
    !isset($_POST["produto_nome"]) ||
    !isset($_POST["preco"]) ||
    !isset($_POST["imagem"])
) {
    die("Erro: Dados do produto não foram enviados corretamente.");
}

$produto_id   = (int) $_POST["produto_id"];
$produto_nome = trim($_POST["produto_nome"]);
$preco        = (float) str_replace(",", ".", $_POST["preco"]);
$imagem       = trim($_POST["imagem"]);

// Busca o peso do produto no banco usando o ID
$peso_produto = 0.300;

$sqlPeso = "SELECT peso FROM produtos WHERE id = ? LIMIT 1";
$stmtPeso = $conn->prepare($sqlPeso);

if ($stmtPeso) {

    $stmtPeso->bind_param("i", $produto_id);
    $stmtPeso->execute();

    $resPeso = $stmtPeso->get_result();

    if ($resPeso->num_rows > 0) {
        $peso_produto = $resPeso->fetch_assoc()["peso"];
    }

    $stmtPeso->close();
}

// Verifica se o produto já está no carrinho
$sqlCheck = "
SELECT
id,
quantidade
FROM carrinho
WHERE usuario_id = ?
AND produto_id = ?
";

$stmtCheck = $conn->prepare($sqlCheck);

if (!$stmtCheck) {
    die($conn->error);
}

$stmtCheck->bind_param("ii", $usuario_id, $produto_id);
$stmtCheck->execute();

$result = $stmtCheck->get_result();

if ($result->num_rows > 0) {

    // Produto já existe -> aumenta quantidade

    $item = $result->fetch_assoc();

    $novaQuantidade = $item["quantidade"] + 1;

    $sqlUpdate = "
    UPDATE carrinho
    SET quantidade = ?
    WHERE id = ?
    ";

    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->bind_param("ii", $novaQuantidade, $item["id"]);
    $stmtUpdate->execute();
    $stmtUpdate->close();

} else {

    // Produto novo -> insere

    $sqlInsert = "
    INSERT INTO carrinho
    (
        usuario_id,
        produto_id,
        produto_nome,
        preco,
        quantidade
    )
    VALUES
    (
        ?, ?, ?, ?, 1
    )
";

$stmtInsert = $conn->prepare($sqlInsert);

if (!$stmtInsert) {
    die("Erro ao preparar inserção no carrinho: " . $conn->error);
}

$stmtInsert->bind_param(
    "iisd",
    $usuario_id,
    $produto_id,
    $produto_nome,
    $preco
);

$stmtInsert->execute();

$stmtInsert->close();
}

$stmtCheck->close();

header("Location: carrinho.php");
exit();
?>