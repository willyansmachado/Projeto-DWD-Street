<?php
session_start();

// Conexão com o Banco de Dados
$host = "localhost";
$user = "root";
$pass = "";
$db   = "dwd_street";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica login
if (!isset($_SESSION['id'])) {
    $_SESSION['id'] = 1; 
}
$usuario_id = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. Pega os dados
    $forma_pagamento = isset($_POST['forma_pagamento']) ? $_POST['forma_pagamento'] : '';
    if ($forma_pagamento == 'Pix') {
        $forma_pagamento = 'PIX';
    }
    
    $cep = isset($_POST['cep']) ? $_POST['cep'] : '';
    $numero = isset($_POST['numero']) ? $_POST['numero'] : '';
    $endereco_rua = isset($_POST['endereco']) ? $_POST['endereco'] : '';
    $bairro = isset($_POST['bairro']) ? $_POST['bairro'] : '';
    
    $endereco_completo = "$endereco_rua, $numero - $bairro. CEP: $cep";

    // PEGA O VALOR DO FRETE QUE O JAVASCRIPT CALCULOU
    $valor_frete = isset($_POST['frete']) ? floatval($_POST['frete']) : 0.00;

    // Calcula o subtotal direto do banco de dados (mais seguro)
    $sql_total = "SELECT SUM(preco * quantidade) as total FROM carrinho WHERE usuario_id = ?";
    $stmt_t = $conn->prepare($sql_total);
    $stmt_t->bind_param("i", $usuario_id);
    $stmt_t->execute();
    $res_t = $stmt_t->get_result()->fetch_assoc();
    $stmt_t->close(); 
    
    $subtotal_pedido = $res_t['total'] ? $res_t['total'] : 0.00;
    
    // Calcula o TOTAL DE VERDADE (Subtotal + Frete)
    $total_pedido = $subtotal_pedido + $valor_frete;

    $endereco_id = 1; 
    
    // Gera o próximo código do pedido
    $result = $conn->query("SELECT MAX(id) AS ultimo FROM pedidos");
    $dados = $result->fetch_assoc();
    $proximo = (int)$dados["ultimo"] + 1;
    $codigo_rastreio = "DWD" . str_pad($proximo, 6, "0", STR_PAD_LEFT);

    $conn->query("SET FOREIGN_KEY_CHECKS = 0");

    $sql_pedido = "INSERT INTO pedidos 
    (
        usuario_id,
        codigo,
        endereco_id,
        subtotal,
        frete,
        total,
        forma_pagamento,
        status,
        criado_em
    ) 
    VALUES (?, ?, ?, ?, ?, ?, ?, 'Aguardando Pagamento', NOW())";
    
    $stmt_p = $conn->prepare($sql_pedido);
    
    if (!$stmt_p) {
        die("Erro ao preparar pedido: " . $conn->error);
    }
    
    $stmt_p->bind_param(
        "isiddds",
        $usuario_id,
        $codigo_rastreio,
        $endereco_id,
        $subtotal_pedido,
        $valor_frete,
        $total_pedido,
        $forma_pagamento
    );
    if ($stmt_p->execute()) {
        $pedido_id = $conn->insert_id;
        $stmt_p->close();

        // 3. Move itens do carrinho
        $sql_carrinho = "SELECT * FROM carrinho WHERE usuario_id = ?";
        $stmt_c = $conn->prepare($sql_carrinho);
        $stmt_c->bind_param("i", $usuario_id);
        $stmt_c->execute();
        $itens_carrinho = $stmt_c->get_result();

        // Prepara as querys que serão usadas repetidamente dentro do loop
        $sql_itens = "INSERT INTO itens_pedido (pedido_id, produto_id, tamanho_id, cor_id, quantidade, preco_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt_i = $conn->prepare($sql_itens);

        $sql_estoque = "UPDATE produtos SET estoque = estoque - ? WHERE id = ?";
        $stmt_e = $conn->prepare($sql_estoque);

        $sql_vendas = "UPDATE produtos SET vendas = vendas + ? WHERE id = ?";
        $stmt_v = $conn->prepare($sql_vendas);

        while ($item = $itens_carrinho->fetch_assoc()) {
            $tamanho_id = isset($item['tamanho_id']) ? $item['tamanho_id'] : null;
            $cor_id = isset($item['cor_id']) ? $item['cor_id'] : null;
            $preco_unitario = $item['preco'];
            $subtotal_item = $preco_unitario * $item['quantidade'];

            // Salva na tabela itens_pedido
            $stmt_i->bind_param("iiiiidd", $pedido_id, $item['produto_id'], $tamanho_id, $cor_id, $item['quantidade'], $preco_unitario, $subtotal_item);
            $stmt_i->execute();

            // Atualiza o estoque do produto
            $stmt_e->bind_param("ii", $item["quantidade"], $item["produto_id"]);
            $stmt_e->execute();

            // Atualiza o contador de vendas do produto
            $stmt_v->bind_param("ii", $item["quantidade"], $item["produto_id"]);
            $stmt_v->execute();
        }
        
        // Fecha todos os statements abertos DEPOIS que o loop acabou
        $stmt_c->close();
        $stmt_i->close();
        $stmt_e->close();
        $stmt_v->close();

        // 4. Limpa o carrinho
        $sql_limpa = "DELETE FROM carrinho WHERE usuario_id = ?";
        $stmt_l = $conn->prepare($sql_limpa);
        $stmt_l->bind_param("i", $usuario_id);
        $stmt_l->execute();
        $stmt_l->close();

        $conn->query("SET FOREIGN_KEY_CHECKS = 1");

        // 5. Sucesso! Redireciona passando o id do pedido
        header("Location: obrigado.php?pedido=" . $pedido_id);
        exit();

    } else {
        $conn->query("SET FOREIGN_KEY_CHECKS = 1");
        die("Erro ao salvar o pedido: " . $stmt_p->error);
    }

} else {
    header("Location: carrinho.php");
    exit();
}
?>